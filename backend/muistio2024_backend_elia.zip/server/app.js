const exp = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const conn = require('./config/db');

dotenv.config();

conn();

const app = exp();

app.use(cors());
app.use(exp.json());

const noteRoutes = require('./routes/note');
app.use('/api/notes', noteRoutes);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));