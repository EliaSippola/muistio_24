const Note = require('../models/note');

// all or one note
exports.getNotes = async (req, res) => {
    if (req.query.id == null) {
        try {
            const notes = await Note.find();
            res.json(notes);
    
            console.log("GET:'/'");
        } catch (err) {
            res.status(500).send('Server Error');
        }
    } else {
        try {
            const id = req.query.id;
    
            const notes = await Note.find({"_id":id});
            res.json(notes);
    
            console.log("GET:'/:id'");
        } catch (err) {
            res.status(500).send('Server Error');
        }
    }
}

// create note
exports.createNote = async (req, res) => {

    try {
        
        let note = new Note;

        note.title = req.body.title;
        note.content = req.body.content;

        await Note.insertMany(note);

        console.log("POST:'/'");

        res.status(200).send("Create succesful\nCreated:\n" + note);
    } catch (err) {
        res.status(500).send('Server Error');
    }
}

// update note
exports.updateNote = async (req, res) => {
    try {
        const id = req.query.id;

        if (id == null) {
            throw new Error('No id specified');
        }
    
        const notes = await Note.findOne({"_id":id});

        if (!notes) {
            throw new Error("No notes found");
        }

        let title = notes.title;
        let content = notes.content;
        let lastModified = notes.lastModified;

        if (req.body.title != null) {
            title = req.body.title;
            lastModified = new Date();
        }
        if (req.body.content != null) {
            content = req.body.content;
            lastModified = new Date();
        }

        await Note.updateOne({"_id":notes._id}, {$set:{"title":title,"content":content,"lastModified":lastModified}});
    
        console.log("PUT:'/:id'");

        res.status(200).send("Update succesful\nUpdated:\n" + notes);
    } catch (err) {
        res.status(500).send('Server ' + err);
    }
}

// delete note
exports.deleteNote = async (req, res) => {
    try {

        const id = req.query.id;

        if (id == null) {
            throw new Error('No id specified');
        }
    
        const notes = await Note.findOne({"_id":id});

        if (!notes) {
            throw new Error("No notes found");
        }

        await Note.deleteOne({"_id":notes._id});

        console.log("DELETE:'/'")

        res.status(200).send("Delete succesful.\nDeleted:\n" + notes);
    } catch (err) {
        res.status(500).send('Server ' + err);
    }
}